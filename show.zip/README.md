# web_show
网站作品展示

上传静态网站zip格式包，会自动进行解压并展示

## 注意事项
- zip压缩包中最好包含index.html，且在根目录下
- html中的文件引用应使用相对路径

## API

- `/`: 文件上传目录
- `/files`: 文件展示目录
- `/file/:username`: 展示指定用户文件